set echo on
spool /F/R2/Backup/Logs/standby_control_nightly.log
alter database create standby controlfile as '/F/R2/Backup/Cold/standby_control_nightly.ctl';
host cp -f /F/R2/Backup/Cold/standby_control_nightly.ctl /F/R2/Backup/Standby_Control
spool off

quit




