REM ***************************************************************************
REM **
REM ** Copyright (c) 1999 by Unique Business Systems. All Rights Reserved.
REM **
REM ** Name: r2shut.sql
REM ** Desc: r2shut.sql is a series of SQL to shutdown Oracle Database.
REM **       This SQL script is called by "r2shut.bat".
REM **
REM ***************************************************************************
spool /F/R2/Backup/Logs/r2shut.log
set echo on
shutdown immediate
startup Exclusive Restrict
Shutdown Normal
spool off
exit

