exec dbms_stats.gather_schema_stats('R2',options=>'GATHER AUTO');
quit;
