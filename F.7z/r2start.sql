REM ***************************************************************************
REM **
REM ** Copyright (c) 1999 by Unique Business Systems. All Rights Reserved.
REM **
REM ** Name: r2start.sql
REM ** Desc: r2start.sql is a series of SQL to start Oracle Database.
REM **       This SQL script is called by "r2start.bat".
REM **
REM ***************************************************************************
spool /F/R2/Backup/Logs/r2start.log
set echo on
startup
spool off
exit

