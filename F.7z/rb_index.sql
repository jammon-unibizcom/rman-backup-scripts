begin
for index_list in (SELECT 'ALTER INDEX '||INDEX_NAME||' Rebuild '||
'TABLESPACE INDX INITRANS 2 MAXTRANS 255 PCTFREE 10 '||
'STORAGE (INITIAL 1040K NEXT 1024K MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1)' alter_command
FROM user_indexes
where table_name not in
      (select table_name
       from user_tab_columns
       where data_type='BLOB')) LOOP
      execute immediate index_list.alter_command;
end loop;
end;
/


quit



