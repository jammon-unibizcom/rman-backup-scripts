startup mount
alter database open resetlogs;

set pages 0
set lines 32767
set feedback off
set trimspool on


spool /F/R2/cloudBackupFull.sql


select 'SET ENCRYPTION IDENTIFIED BY "'||dbid||'" only;'||chr(10)||
'BACKUP as compressed backupset INCREMENTAL LEVEL 0 SECTION SIZE 512M DATABASE PLUS ARCHIVELOG;'||chr(10)||
'BACKUP as compressed backupset ARCHIVELOG ALL NOT BACKED UP 2 TIMES;'||chr(10)||
'CROSSCHECK BACKUP;'||chr(10)||
'DELETE NOPROMPT OBSOLETE device type sbt_tape;'||chr(10)||
'DELETE NOPROMPT OBSOLETE device type disk;'||chr(10)||
'DELETE NOPROMPT EXPIRED BACKUP;'
from v$database
/



spool off

spool /F/R2/cloudBackupArchivelog.sql

select 'SET ENCRYPTION IDENTIFIED BY "'||dbid||'" only;'||chr(10)||
'BACKUP as compressed backupset ARCHIVELOG ALL NOT BACKED UP 2 TIMES;'||chr(10)||
'CROSSCHECK BACKUP;'||chr(10)||
'DELETE NOPROMPT OBSOLETE device type sbt_tape;'||chr(10)||
'DELETE NOPROMPT OBSOLETE device type disk;'||chr(10)||
'DELETE NOPROMPT EXPIRED BACKUP;'
from v$database
/


spool off


spool /F/R2/cloudBackupCleanup.sql

select 'SET ENCRYPTION IDENTIFIED BY "'||dbid||'" only;'||chr(10)||
'CROSSCHECK BACKUP;'||chr(10)||
'DELETE NOPROMPT OBSOLETE device type sbt_tape;'||chr(10)||
'DELETE NOPROMPT OBSOLETE device type disk;'||chr(10)||
'DELETE NOPROMPT EXPIRED BACKUP;'
from v$database
/

spool off

quit

