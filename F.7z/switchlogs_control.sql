spool /F/R2/Backup/Logs/switchlog_control.log

alter system archive log current;

alter database create standby controlfile as '/F/R2/Backup/Standby_Control/standby_control.ctl';



spool off

quit




