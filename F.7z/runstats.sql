spool /F/R2/Backup/Logs/TransferStat.log
exec ProductDailyTransferStatsData.DailyReceivedProduct(sysdate);
Exec TransferStatsData.TransferProduct(0);
Exec TransferStatsData.TransferSite(0);
Exec TransferStatsData.TransferEmployee(0);
Exec TransferStatsData.TransferRevenue(Trunc(Sysdate),1);
Exec Proc_UpdateMonthlyRevenue(sysdate);
spool off
exit;


