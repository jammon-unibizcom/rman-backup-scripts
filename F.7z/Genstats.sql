SET ECHO ON
SET LINES 30000
SET TRIMSPOOL ON
SET LINES 50000
set serveroutput on size unlimited
SPOOL /F/R2/Backup/Logs/GENSTATS.LOG



begin
declare checker_number NUMBER(9);
begin
select count(*)
into checker_number
from user_objects
where object_name='TRANSFERSTATSDATA';
IF CHECKER_NUMBER>0 THEN
execute immediate 'begin TransferStatsData.TransferEmployee(0); end;';
commit;
execute immediate 'begin TransferStatsData.TransferSite(0); end;';
commit;
execute immediate 'begin TransferStatsData.TransferRevenue(sysdate); end;';
commit;
END IF;
END;
end;
/

SPOOL OFF



quit


--exec TransferStatsData.TransferEmployee(0);
--Commit;
--exec TransferStatsData.TransferSite(0);
--Commit;
--exec TransferStatsData.TransferRevenue(sysdate);
--Commit;

--quit


