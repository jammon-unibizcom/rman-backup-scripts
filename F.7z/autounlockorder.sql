SET ECHO ON
SET LINES 30000
SET TRIMSPOOL ON
SET LINES 50000
SPOOL /F/R2/Backup/Logs/AUTOUNLOCKORDER.LOG


declare
lock_detected	Exception;
PRAGMA EXCEPTION_INIT(Lock_detected,-00054);
Mcontract contract%rowtype;
begin
For Morder in (select * from contract where lockcount>0) Loop
	begin
	   select * into Mcontract from contract where contractiid=Morder.contractiid
		for update nowait;
	   update contract set lockcount=0,inuseby=null where
			contractiid=Morder.contractiid;
     		splitshippinglines(morder.contractiid,0,0,sysdate,100001);
		splitshippinglines(morder.contractiid,1,0,sysdate,100001);
		commit;		   	
	exception
		when lock_detected then
			rollback;
			null;
		when others then
			rollback;
			null;
	end;
end loop;
end;
/



--CLEARUNDOACTIONS
begin
declare checker_number NUMBER(9);
begin
select count(*)
into checker_number
from user_objects
where object_name='CLEARUNDOACTIONS';
IF CHECKER_NUMBER>0 THEN
execute immediate 'begin CLEARUNDOACTIONS; end;';
END IF;
END;
end;
/


--Purge old invusage records
declare iteration_count number(9);
begin
select ceil((count(*)/1000)) 
into iteration_count
from invusage
where trunc(endtime,'dd')<trunc(sysdate,'dd')-365;
for a in 1..iteration_count loop
delete from invusage
where trunc(endtime,'dd')<trunc(sysdate,'dd')-365 and
      rownum<=1000;
commit;
end loop;
end;
/

--Genconflicts
begin
declare checker_number NUMBER(9);
begin
select count(*)
into checker_number
from user_objects
where object_name='GENCONFLICTS';
IF CHECKER_NUMBER>0 THEN
execute immediate 'begin GENCONFLICTS; end;';
END IF;
END;
end;
/


----GENERATEAUTOMATEDACTIVITY
--begin
--declare checker_number NUMBER(9);
--begin
--select count(*)
--into checker_number
--from user_objects
--where object_name='GENERATEAUTOMATEDACTIVITY';
--IF CHECKER_NUMBER>0 THEN
--execute immediate 'begin GENERATEAUTOMATEDACTIVITY; end;';
--END IF;
--END;
--end;
--/


SPOOL OFF

quit




