spool /F/R2/Backup/Logs/AutoRebuildInd_R2.log APPEND
SELECT TO_CHAR(SYSDATE,'MM/DD/YYYY HH24:MI:SS') CURRENT_TIME FROM DUAL;


begin
for a in (select 'alter index '||index_name||' rebuild' rb_stmnt from user_indexes where status='UNUSABLE') LOOP
EXECUTE IMMEDIATE A.RB_STMNT;
end loop;
end;
/

begin
for a in (select DECODE(INDEX_TYPE,'NORMAL','alter index '||index_name||' rebuild TABLESPACE INDX','ALTER TABLE '||TABLE_NAME||' MOVE TABLESPACE INDX') rb_stmnt from user_indexes where TABLESPACE_NAME='USR' AND LOGGING='NO') LOOP
EXECUTE IMMEDIATE A.RB_STMNT;
end loop;
end;
/
spool off
