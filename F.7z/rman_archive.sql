CONFIGURE ENCRYPTION FOR DATABASE OFF;
run {
allocate channel t1 type disk;
backup archivelog all format '/F/R2/Backup/Archivelog/One/arch_%d_%u_%s';
delete archivelog all backed up 2 times to device type SBT_TAPE;
release channel t1;
}
CONFIGURE ENCRYPTION FOR DATABASE ON;
