Create or replace procedure GenConflicts
as
begin
Generateconflicts(0,7,sysdate,0);
commit;
end;
/


quit




