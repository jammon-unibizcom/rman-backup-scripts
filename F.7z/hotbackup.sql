set pages 0
set lines 30000
set feedback off
set trimspool on
set termout off
set serveroutput on size unlimited


--Main Datafiles backup

host echo $(date) rm -rf /F/R2/Backup/Cold/* >>/F/R2/Backup/Logs/hotbackup.log
host rm -rf /F/R2/Backup/Cold/* >>/F/R2/Backup/Logs/hotbackup.log

spool /F/R2/execute_hotbackup.sql

BEGIN FOR A IN
(SELECT TABLESPACE_NAME,
        'ALTER TABLESPACE '||
        TABLESPACE_NAME||
        ' BEGIN BACKUP;' START_COMMAND,
        'ALTER TABLESPACE '||
        TABLESPACE_NAME||
        ' END BACKUP;' END_COMMAND
 FROM DBA_TABLESPACES
 where TABLESPACE_NAME<>'TEMPORARY') LOOP
dbms_output.put_line (A.START_COMMAND);
FOR B IN
(SELECT 'cp -f '||
        FILE_NAME||
        ' /F/R2/Backup/Cold>>/F/R2/Backup/Logs/hotbackup.log' COPY_COMMAND
        FROM DBA_DATA_FILES
        WHERE TABLESPACE_NAME=A.TABLESPACE_NAME) LOOP
dbms_output.put_line ('host echo $(date):  '||B.COPY_COMMAND);
dbms_output.put_line ('host '||B.COPY_COMMAND);
END LOOP; --B LOOP
dbms_output.put_line(A.END_COMMAND);
END LOOP; --A LOOP
END;
/


spool off

start /F/R2/execute_hotbackup.sql


--Oracle Configuration backup

host echo $(date):  cp -f /C/R2Database/product/12.2.0/db_1/dbs/spfileR2.ora /F/R2/Backup/Cold>>/F/R2/Backup/Logs/hotbackup.log
host cp -f /C/R2Database/product/12.2.0/db_1/dbs/spfileR2.ora /F/R2/Backup/Cold>>/F/R2/Backup/Logs/hotbackup.log
host echo $(date):  cp -f /C/R2Database/product/12.2.0/db_1/dbs/initR2.ora  /F/R2/Backup/Cold>>/F/R2/Backup/Logs/hotbackup.log
host cp -f /C/R2Database/product/12.2.0/db_1/dbs/initR2.ora  /F/R2/Backup/Cold>>/F/R2/Backup/Logs/hotbackup.log

--Redo Log Backup
set serveroutput on size unlimited
spool /F/R2/gen_redobck.sql

select 'set pages 0'||
       chr(13)||chr(10)||
       'set lines 30000'||
       chr(13)||chr(10)||
       'set feedback off'||
       chr(13)||chr(10)||
       'set trimspool on'||
       chr(13)||chr(10)||
       'set termout off'||
       chr(13)||chr(10)||
       'set serveroutput on size 1000000'||
       chr(13)||chr(10)||
       'var max_group# number'||
       chr(13)||chr(10)||
       'begin'||
       chr(13)||chr(10)||
       'select max(group#) into :max_group# from v$logfile;'||
       chr(13)||chr(10)||
       'end;'||
       chr(13)||chr(10)||
       '/'||
       chr(13)||chr(10)||
       chr(13)||chr(10)||
       chr(13)||chr(10)||
       chr(13)||chr(10)       
from dual;


declare max_redogroup number(9);
begin
select max(group#) into max_redogroup from v$logfile;
for a in 1..max_redogroup loop
dbms_output.put_line('alter system switch logfile;');
dbms_output.put_line(chr(13)||chr(10));
dbms_output.put_line('spool /F/R2/bckredo.sql');
dbms_output.put_line(chr(13)||chr(10));
dbms_output.put_line('select ''host echo $(date):  cp -f ''||vlf.member||'' /F/R2/Backup/Cold>>/F/R2/Backup/Logs/hotbackup.log''||');
dbms_output.put_line('       chr(13)||chr(10)||');
dbms_output.put_line('       ''host cp -f ''||vlf.member||'' /F/R2/Backup/Cold>>/F/R2/Backup/Logs/hotbackup.log''');
dbms_output.put_line('from');
dbms_output.put_line('v$logfile vlf,');
dbms_output.put_line('(select decode(group#,:max_group#-1,1,:max_group#,2,group#+2) group#');
dbms_output.put_line('from v$log');
dbms_output.put_line('where status=''CURRENT'') vl');
dbms_output.put_line('where vl.group#=vlf.group#;');
dbms_output.put_line(chr(13)||chr(10));
dbms_output.put_line(chr(13)||chr(10));
dbms_output.put_line('spool off');
dbms_output.put_line(chr(13)||chr(10));
dbms_output.put_line(chr(13)||chr(10));
dbms_output.put_line(chr(13)||chr(10));
dbms_output.put_line('start /F/R2/bckredo.sql');
dbms_output.put_line(chr(13)||chr(10));
dbms_output.put_line(chr(13)||chr(10));
dbms_output.put_line(chr(13)||chr(10));
end loop;
end;
/


spool off


start /F/R2/gen_redobck.sql



--Control File Backup

host rm -rf /F/R2/Backup/Standby_Control/STANDBY_CONTROL.CTL

alter database create standby controlfile as '/F/R2/Backup/Standby_Control/STANDBY_CONTROL.CTL';

spool /F/R2/Bck_control.sql

SELECT 'host echo $(date):  cp -f /F/R2/Backup/Standby_Control/STANDBY_CONTROL.CTL /F/R2/Backup/Cold/'||
       SUBSTR(NAME,15,512)||
       '>>/F/R2/Backup/Logs/hotbackup.log'||
       chr(13)||chr(10)||
       'host cp -f /F/R2/Backup/Standby_Control/STANDBY_CONTROL.CTL /F/R2/Backup/Cold/'||
       SUBSTR(NAME,15,512)||
       '>>/F/R2/Backup/Logs/hotbackup.log'
FROM V$CONTROLFILE
/


spool off


start /F/R2/Bck_control.sql
start /F/R2/standby_control_nightly.sql

quit






